#include <iostream>
#include <string>
using namespace std;
//TASK (4)                                    (4)
//void main(){
//	int a = 0;
//	int b = 0;
//	int c = 0;
//	int d = 0;
//	cout << "enter the first number"<<endl;
//		cin >> a;
//		cout << "enter the second number " <<endl;;
//		cin >> b;
//		cout << " enter the third number"<<endl;
//		cin >> c;
//		d = a + b + c;
//		if (a!=b && b!=c && a!=c)
//		{
//			cout << d;
//		}
//		if (a==b  )
//		{
//			cout << c;
//		}
//		if (b==c)
//		{
//			cout << a;
//		}
//		if (a==c)
//		{
//			cout << b;
//		}
//		if (a==b&&b==c&&c==a)
//		{
//			cout << "eroor.sss";
//		}
//		system ("pause");
//
//}
//Task (5)            (5)
//void main(){
//	int a = 0;
//	int b = 0;
//	int c = 0;
//	cout << "enter 1st number" << endl;
//	cin >> a;
//	cout << "enter 2nd number" << endl;
//	cin >> b;
//	cout << "enter 3rd number" << endl;
//	cin >> c;
//	if (a==b || b==c || c==a)
//	{
//		cout << "duplicate exist" << endl;
//	}
//	else
//	{
//		cout << "duplicate do not exist" << endl;
//	}
//	system("pause");
//}
//task(6)               (6)
//void main(){
//	int a = 0;
//	int b = 0;
//	int c = 0;
//	int d = 0;
//	cout << "enter 1st number " << endl;
//	cin >> a;
//	cout << "enter 2nd number" << endl;
//	cin >> b;
//	cout << "enter 3rd number" << endl;
//	cin >> c;
//	cout << "enter 4th number: " << endl;
//	cin >> d;
//	if (a > b)
//	{
//		if (a > c){
//			if (a > d){
//				cout << "the greatest number is " << a;
//			}
//		}
//	}
//
//
//	if (b > a)
//	{
//		if (b > c){
//			if (b > d){
//				cout << "the greatest number is : " << b;
//			}
//		}
//	}
//
//	if (c > a)
//	{
//		if (c > b){
//			if (c > d){
//				cout << "the greatest numer is : " << c;
//			}
//		}
//
//	}
//
//	if (d>a)
//	{
//		if (d > b){
//			if (d > c){
//				cout << "the greatest numbere is : " << endl;
//			}
//		}
//
//	}
//	system("pause");
//}
//Task (7)            (7)
//void main(){
//	int a = 0;
//	int b = 0;
//	char ch;
//	cout << "enter 1st number  " << endl;
//	cin >> a;
//	cout << "enter 2nd number " << endl;
//	cin >> b;
//	cout << "enter the operater" << endl;
//	cin >> ch;
//	if (ch=='+')
//	{
//		cout << a + b;
//	}
//	else if (ch=='-')
//	{
//		cout << a - b;
//
//	}
//	else if (ch == '*')
//	{
//		cout << a*b;
//	}
//	else if (ch=='/')
//	{
//		cout << a / b;
//	}
//	else if (ch =='%')
//	{
//		cout << a%b;
//
//	}
//	system("pause");
//}
// Task (10)              (10)
//void main(){
//	int month ;
//	cout << "enter your  number" << endl;
//	cin >> month;
//	if (month == 1)
//	{
//		cout << "january" << endl;
//	}
//	else if (month == 2){
//		cout << "feburary" << endl;
//}
//	else if (month==3)
//	{
//		cout << "march" << endl;
//	}
//	else if (month ==4)
//	{
//		cout << "aprial" << endl;
//
//	}
//	else if (month == 5)
//	{
//		cout << "may" << endl;
//
//	}
//	else if (month == 6)
//	{
//		cout << "june" << endl;
//
//	}
//	else if (month == 7)
//	{
//		cout << "july" << endl;
//
//	}
//	else if (month == 8)
//	{
//		cout << "august" << endl;
//
//	}
//	else if (month == 9)
//	{
//		cout << "september" << endl;
//
//	}
//	else if (month == 10)
//	{
//		cout << "october" << endl;
//
//	}
//	else if (month == 11)
//	{
//		cout << "november" << endl;
//
//	}
//	else if (month == 12)
//	{
//		cout << "december" << endl;
//
//	}
//	else if (month  <1|| month>12 )
//	{
//		cout << "ERROR months are from 1-12 so,please enter 1-12 numbers" << endl;
//
//	}
//	system("pause ");
//}
//Tasak (9)           (9)
//void main(){
//	int a;
//	int b;
//	cout << "enter your number " << endl;
//	cin >> a;
//	if (a >0)
//	{
//		cout << "the number is positive" << endl;
//		if (a % 2 == 0)
//		{
//			cout << "the number is even" << endl;
//		}
//		else
//		{
//			cout << "the number is odd "<< endl;
//		}
//	}
//	if (a<0)
//	{
//		a = abs(a);
//			b = sqrt(a);
//			if (b*b==a)
//			{
//				cout << "the number is negative and aperfect square with his absolute" << endl;
//
//			}
//			else
//			{
//				cout << "the number is negative and not a perfect square with his absolute" << endl;
//
//			}
//	}
//	system("pause");
//}
// Task (8)                           (8)
void main(){
	int speed;
	string date;
	string birthday = "26/4/2005";
	cout << "Enter your birthday like (26/4/2005) : \n";
	cin >> date;
	cout << "Enter the speed : \n";
	cin >> speed;
	cout << "integer value: 0 = no ticket, 1=small ticket, 2=big ticket\n";
	if (date==birthday)
	{
		if (speed <= 65) {
			cout << "0\n";
		}
		else if (66 <= speed <= 85) {
			cout << "1\n";
		}
		else if (speed >= 86) {
			cout << "2\n";
		}
		
	}
	else
	{
		if (speed <= 60) {
			cout << "0\n";
		}
		else if (61 <= speed <= 80) {
			cout << "1\n";
		}
		else if (speed >= 81) {
			cout << "2\n";
		}
	}

		system("pause");
}
