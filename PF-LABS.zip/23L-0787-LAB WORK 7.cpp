#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int choice = 0;
	char Qn;
	do
	{
		cout << "Please Enter QN: 1, 2, 3, 4, 5, 6, 7, 8 , 9, 0"<<endl;
		cin >> Qn;
		switch (Qn)
		{
		case '1':
		{int  i, a, b, c = 1;
		cout << "Enter the number  : " << endl;
		cin >> a;
		cout << "Enter its power" << endl;
		cin >> b;
		if (b > 0 && b < 14)
		{
			i = b;
			do
			{
				c *= a;
				--b;
			} while (b != 0);

			cout << a << " raised to the power of " << i << " is equal to the " << c << endl;
		}
		else if (b == 0)
		{
			c = 0;
			cout << a << " raised to the power of " << b << " is equal to the " << c << endl;
		}
		else if (b > 14) {
			cout << "Please entert the power less than 14 as this is simple multiplication " << endl;
		}
		else
		{
			cout << "please enter your power positive (greater than zero) " << endl;
		}
		}
		break;
		case '2':
		{

			int n1, n2, i, n, b, c, count;

			cout << "Enter first number: ";
			cin >> n1;

			cout << "Enter second number: ";
			cin >> n2;

			if (n1 > n2) {
				n1 = n1 + n2;
				n2 = n1 - n2;
				n1 = n1 - n2;
			}

			cout << "Armstrong numbers between " << n1 << " and " << n2 << " are: " << endl;


			for (i = n1; i <= n2; i++) {


				count = 0;


				n = i;


				while (n > 0) {
					++count;
					n /= 10;
				}


				c = 0;


				n = i;


				while (n > 0) {
					b = n % 10;
					c = c + pow(b, count);
					n /= 10;
				}

				if (c == i) {
					cout << i << ", ";
				}
			}


		}
		break;
		case'3': {
			int a, b, c, i = 1;
			cout << "Enter the number : " << endl;
			cin >> a;
			cout << "Enter the limit of table " << endl;
			cin >> b;
			if (b > 0 && a > 0) {
				do
				{
					c = i * a;
					cout << a << " * " << i << " = " << c << endl;
					++i;
				} while (i <= b);
			}
			else
			{
				cout << "Pleases enter positive numbers ! " << endl;
			}
		}
			   break;

		case '4':
		{
			int a, b;
			cout << "Please enter your starting  point :" << endl;
			cin >> a;
			cout << "Please enter your  ending point :" << endl;
			cin >> b;
			for (int i = a; i >= b; --i)
			{
				for (int j = i; j >= b; --j)
				{
					cout << i;
				}
				cout << endl;
			}
		}
		break;

		case '5':
		{
			int n, j = 1, sum = 0;

			cout << "Enter a positive integer: ";
			cin >> n;
			if (n > 0)
			{
				do
				{
					cout << "(" << j << " ^ 2) + ";
					++j;
				} while (j <= n);

				for (int i = 1; i <= n; ++i) {
					sum += pow(i, 2);
				}
				cout << "=" << sum;
			}
			else
			{
				cout << "Please enter a positive number . " << endl;
			}

		}
		break;

		case '6': {
			float n, a = 0.0;
			float b = 0.0;
			cout << "Enter a Positive intiger N :" << endl;
			cin >> n;
			for (int i = 1; i <= n; ++i)
			{
				a += 2;
				cout << " (1/" << a << ") + ";
				b += 1 / a;
			}
			cout << "=" << b << endl;
		}
				break;

		case '7':
		{
			for (int i = 1; i <= 10; i++)
			{
				if (i == 1 || i == 10)
				{
					cout << "============================" << endl;
				}
				else
				{
					cout << "=                          =" << endl;
				}
			}
		}
		break;
		case '8': {
			int a, b;
			cout << " Program has to print Table from : " << endl;
			cin >> a;
			cout << "To" << endl;
			cin >> b;
			for (int i = a; i <= b; ++i)
			{
				int c = 0;
				for (int j = 10; j >= 1; --j)
				{

					c = c + i;
					cout << c << " ";
				}
				cout << endl;
			}
		}
				break;
		case '9':
		{
			int i, n, d, s = 0;
			cout << "Enter your number  : ";
			cin >> n;
			for (i = 1; i < n; i++)
			{
				d = n % i;
				if (d == 0)
					s = s + i;
			}
			if (s == n)
				cout << n << " is a perfect number " << endl;
			else
				cout << n << " is not a perfect number" << endl;

		}
		break;
		case'0':
		{
			int n = 2;
			do {
				cout << "- - - - - * - - - - -" << endl;
				cout << "- - - - * - * - - - -" << endl;
				cout << "- - - * - - - * - - -" << endl;
				cout << "- - * - - - - - * - -" << endl;
				cout << "- * - - - - - - - * -" << endl;
				cout << "* - - - - - - - - - *" << endl;
				n++;
			} while (n == 2);
				cout << endl;
		}
			break;
		default:
			cout << "Wrong Input !" << endl;

		}
		cout << "Press 1 if you want to ReRun this programe. Press any other key to exit"<<endl;
		cin >> choice;
	} while (choice == 1);

	system("pause");

	return 0;
}