#include <iostream>
#include <cstring>
using namespace std;

void printASCII(char a);
int sumordiff(int a, int b);
void oddfun(int n);
void movezeroToEnd(int A[], int size);
void concatenateStrings(char A3[], char A1[], char A2[]);
int lexicographical_comparison(char A1[], char A2[]);
int findLongestName(char names[], int count);
bool isRotation(char str1[], char str2[]);
bool ifisPrime(int a);
void findMinMax(int A[], int size, int& minValue, int& maxValue);
int main()
{
    int choice = 0;
    char Qn;
    do
    {
        cout << "Please Enter QN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 0. " << endl;
        cin >> Qn;
        switch (Qn)
        {
        case '1':
        {
            char a;
            cout << "Enter the character : " << endl;
            cin >> a;
            printASCII(a);
        }

            break;

        case '2':
        {
            int n1, n2, n3;
            cout << "Enter the First Number: " << endl;
            cin >> n1;
            cout << "Enter the Second Number: " << endl;
            cin >> n2;
            n3 = sumordiff(n1, n2);
            cout << n3 << endl;
        }

            break;
        case '3':
        {
            int n;
            cout << "Enter the number of terms : " << endl;
            cin >> n;
            oddfun(n);
        }
            break;

        case '4':
        {
            int arr[100], c = 0, v;
            cout << "Enter elements in an array. Enter '-1' to stop. " << endl;
            for (int i = 0; i < 100; i++) {
                cin >> v;
                if (v == -1)
                    break;
                arr[i] = v;
                c++;
            }
            movezeroToEnd(arr, c);
            cout << "Sorted array : ";
            for (int i = 0; i < c; i++)
                cout << arr[i] << " ";
            cout << endl;

        }

            break;

        case '5':
        {
            char A1[100],A2[100], A3[200];
            cout << "Enter elements of the first array: " << endl;
            cin.ignore();
            cin.getline(A1, 100);
            cout << "Enter elements of the second array: " << endl;
            cin.getline(A2, 100);
            
            concatenateStrings(A3, A1, A2);
            
            
        }
    

            break;

        case '6':
        {
            char A1[100], A2[100];
            cout << "Your 1st entered array is : ";
            cin.ignore();
            cin.getline(A1, 100);
            cout << "Your 2nd entered array is : ";
            cin.getline(A2, 100);
            int size1 = strlen(A1), size2 = strlen(A2);
            if (lexicographical_comparison(A1, A2) == 1) {
                cout << endl;
                cout << "String 1: ";
                for (int i = 0; i < size1; i++)
                    cout << A1[i];
                cout << "' comes before String 2: '";
                for (int i = 0; i < size2; i++)
                    cout << A2[i];
                cout << "' Lexicographically." << endl;
            }
            else {
                cout << endl;
                cout << "String 2: '";
                for (int i = 0; i < size2; i++)
                    cout << A2[i];
                cout << "' comes before String 1: '";
                for (int i = 0; i < size1; i++)
                    cout << A1[i];
                cout << "' Lexicographically.";
                cout << endl;
            }

        }


            break;

        case '7':
        {
            char A[100];
            cout << "Enter student names separated by spaces: ";
            cin.ignore();
            cin.getline(A, 100);
            int a, size = strlen(A);
            a = findLongestName(A, size);
            cout << "Index of the longest name is: " << a << endl;
        }

     

            break;
        case '8': 
        {
            char arr1[100], arr2[100];
            cout << "Your 1st entered array is: ";
            cin.ignore();
            cin.getline(arr1, 100);
            cout << "Your 2nd entered array is: ";
            cin.getline(arr2, 100);
            if (isRotation(arr1, arr2) == true) {
                cout << endl;
                cout << "The strings are rotation of each other." << endl;
            }
            else {
                cout << endl;
                cout << "The strings are not rotation of each other." << endl;
            }
        }
            break;
        case '9':
        {
            int a;
            cout << "Enter a number to check if it's prime: " << endl;
            cin >> a;
            if (a < 2)
                cout << a << " is not a prime number. " << endl;
            else if (ifisPrime(a)) {
                cout << a << " is a prime number.\n";
            }
            else {
                cout << a << " is not a prime number. " << endl;
            }
        }
            break;
        case '0':
        {
            int A[100], v, min = 999, max = -999, c = 0;
            cout << "Enter elements in the array. ('-100' to stop): ";
            for (int i = 0; i < 100; i++) {
                cin >> v;
                if (v == -100) {
                    break;
                }
                else {
                    A[i] = v;
                    c++;
                }
            }
            findMinMax(A, c, min, max);
            cout << "Largest = " << max << endl;
            cout << "Smallest = " << min << endl;
        }
            break;
        default:
            cout << "Wrong Input \n";

        }
        cout << "\nPress 1 if you want to ReRun this programe\n Press any other key to exit";
        cin >> choice;
    } while (choice == 1);

    system("pause");

    return 0;
}

void printASCII(char a) {
    a++;
    for (int i = 0; i < 5; i++) {
        cout << a << ": ";
        int ascii = a;
        cout << ascii << "  ";
        a++;
    }
    cout << endl;
}

int sumordiff(int a, int b) {
    int ans;
    if ((a % 7 == 0 && b % 7 == 0) && (a % 5 == 0 && b % 5 == 0) && (a % 3 == 0 && b % 3 == 0)) {

        ans = a + b;
    }
    else {
        ans = a - b;
    }
    return ans;
}

void oddfun(int n) {
    int sum = 0;
    cout << "The odd numbers are: ";
    for (int i = 1; i < 2 * n; i += 2) {
        cout << i << " ";
        sum += i;
    }
    cout << "\nThe Sum of odd Natural Numbers up to " << n << " are: " << sum << endl;
}

void movezeroToEnd(int A[], int size) {
    int count = size;
    for (int i = count - 1; i >= 0; i--) {
        if (A[i] == 0) {
            for (int j = i; j < count - 1; j++)
                swap(A[j], A[j + 1]);
        }
    }
}

void concatenateStrings(char A3[], char A1[], char A2[]) {
    int size1 = strlen(A1), size2 = strlen(A2);
    for (int i = 0; i < size1; i++)
        A3[i] = A1[i];
    for (int i = 0; i < size2; i++)
        A3[i + size1] = A2[i];
    int size3;
    size3 = size1 + size2;
    cout << "After Concatenation : ";
    for (int i = 0; i < size3; i++)
        cout << A3[i];
    cout << endl;
}

int lexicographical_comparison(char A1[], char A2[]) {
    int size1 = strlen(A1), size2 = strlen(A2);
    for (int i = 0; i < size2; i++) {
        if (A1[i] == '\0')
            break;
        else {
            if (A1[i] > A2[i])
                return 0;
        }
    }
    return 1;
}

int findLongestName(char names[], int count) {
    int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, h = 0;
    for (int i = 0; i < count; i++) {
        if (names[i] != ' ') {
            b++;
        }
        else if (names[i] == ' ') {

            ++d;
            if (d == 1)
            {
                c = b;
                b = 0;
            }
            else if (d == 2)
            {

                e = b;
                b = 0;
            }
            else   if (d == 3)
            {
                f = b;
                b = 0;
            }
            else if (d == 4)
            {
                g = b;
                b = 0;
            }
            else  if (d == 5)
            {
                h = b;
                b = 0;
            }
            else {
                h = 5;
            }
        }
    }
    if (c > e && c > f && c > g && c > h)
    {
        a = c;
    }
    else if (e > c && e > f && e > g && e > h)
    {
        a = e;
    }
    else  if (f > e && f > c && f > g && f > h)
    {
        a = f;
    }
    else if (g > e && g > f && g > c && g > h)
    {
        a = g;
    }
    else if (h > e && h > f && h > g && h > c)
    {
        a = h;
    }
    else
    {
        a = 5;
    }
    return a;
}

bool isRotation(char str1[], char str2[]) {
    int size1 = strlen(str1), size2 = strlen(str2), c = 0, c2 = 0;
    bool check = false;
    if (size1 == size2) {
        while (c < size1) {
            if (str1[c] == str2[c2]) {
                check = true;
                c++;
                c2++;
            }
            else if (check) {
                check = false;
                break;
            }
            else {
                check = false;
                c2++;
            }
            if (c2 == size2)
                c2 = 0;
        }
    }
    return check;
}

bool ifisPrime(int a) {
    int N = a / 2;
    for (int i = 2; i <= N; i++) {
        if ((a % i) == 0)
            return false;
    }
    return true;
}

void findMinMax(int A[], int size, int& minValue, int& maxValue) {
    for (int i = 0; i < size; i++) {
        if (A[i] > maxValue)
            maxValue = A[i];
        if (A[i] < minValue)
            minValue = A[i];
    }
}