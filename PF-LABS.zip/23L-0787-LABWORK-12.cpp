
//23L-07887                           ABDUL-REHMAN NASEER                                 1J2
#include <iostream>
#include<cstring>
#include<algorithm>
using namespace std;

void takeInput(int matrix[][5], const int rows, const int columns) {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < columns; j++) {
			cin >> matrix[i][j];

		}

	}
}
void printMatrix(const int matrix[][5], const int rows, const int columns) {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < columns; j++) {
			cout << matrix[i][j] << " ";
		}
		cout << endl;
	}
}
void takeTranspose(int matrix[][5], const int rows, const int columns) {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < columns; j++) {
			swap(matrix[j][i], matrix[i][j]);
		}
	}
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < columns; j++) {
			cout << matrix[j][i] << " ";
		}
		cout << endl;
	}
}
void printMenu(const char strs[][50], int numStrs) {
	cout << "Choose a string to copy:" << endl;
	for (int i = 0; i < numStrs; ++i) {
		cout << i + 1 << ". " << strs[i] << endl;
	}
}

void copyStr(char d[], const char s[]) {
	int i = 0;
	while (s[i] != '\0') {
		d[i] = s[i];
		++i;
	}
	d[i] = '\0';
}

bool isL(char ch) {
	return ch >= 'a' && ch <= 'z';
}

bool isA(char ch) {
	return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');
}

bool isS(char ch) {
	return ch == ' ';
}

void cor(char strs[3][50]) {
	for (int i = 0; i < 3; ++i) {
		int j = 0;
		int k = 0;

		while (strs[i][k] != '\0') {
			if (isL(strs[i][k])) {
				strs[i][j] = strs[i][k] - ('a' - 'A');
				++j;
			}
			else if (isA(strs[i][k])) {
				strs[i][j] = strs[i][k];
				++j;
			}

			++k;
		}

		strs[i][j] = '\0';

		j = 0;
		k = 0;
		while (strs[i][k] != '\0') {
			if (!isS(strs[i][k])) {
				strs[i][j] = strs[i][k];
				++j;
			}
			++k;
		}

		strs[i][j] = '\0';
	}
}
void sortRow(int arr[3][5], int rIdx) {
	if (rIdx >= 0 && rIdx < 3) {
		for (int i = 0; i < 5 - 1; ++i) {
			for (int j = 0; j < 5 - i - 1; ++j) {
				if (arr[rIdx][j] > arr[rIdx][j + 1]) {
					int temp = arr[rIdx][j];
					arr[rIdx][j] = arr[rIdx][j + 1];
					arr[rIdx][j + 1] = temp;
				}
			}
		}
	}
	else {
		cout << "Invalid row index." << endl;
	}
}
void reverseEachString(char arr[][100]) {
	for (int i = 0; i < 3; ++i) {
		if (arr[i][0] != '\0') {
			int len = strlen(arr[i]);
			for (int j = 0; j < len / 2; ++j) {
				swap(arr[i][j], arr[i][len - 1 - j]);
			}
		}
	}
}

void rotateEachString(char arr[][100]) {
	for (int i = 0; i < 3; ++i) {
		if (arr[i][0] != '\0') { 
			int len = strlen(arr[i]);
			char temp = arr[i][len - 1];

			for (int j = len - 1; j > 0; --j) {
				arr[i][j] = arr[i][j - 1];
			}

			arr[i][0] = temp;
		}
	}
}

void readStrings(char A8[][100]) {
	cin.getline(A8[0], 100);
	for (int i = 0; i < 3; ++i) {
		cout << "Enter string " << i + 1 << ": ";
		cin.getline(A8[i], 100);
	}
}

void sortRow(char A8[][100], int n) {
	if (n < 0 || n >= 3) {
		cout << "Invalid row index. Please enter a valid row index." << endl;
		return;
	}

	if (A8[n][0] != '\0') {
		int len = strlen(A8[n]);
		sort(A8[n], A8[n] + len);
	}
}

void printStrings(char A8[][100], const char* label) {
	cout << endl << label << " strings:" << endl;
	for (int i = 0; i < 3; ++i) {
		if (A8[i][0] != '\0') {
			cout << A8[i] << endl;
		}
	}
}

void displayMatrix(int mat[][100], int size) {
	for (int i = 0; i < size; ++i) {
		for (int j = 0; j < size; ++j) {
			cout << mat[i][j] << " ";
		}
		cout << endl;
	}
}

bool isSymmetric(int mat[][100], int size) {
	for (int i = 0; i < size; ++i) {
		for (int j = 0; j < size; ++j) {
			if (mat[i][j] != mat[j][i]) {
				return false;
			}
		}
	}
	return true;
}

int main()
{
	int choice = 0;
	char Qn;
	do
	{
		cout << "Please Enter QN: 1, 2, 3, 4, 5, 6, 7, 8, 9 \t";
		cin >> Qn;
		switch (Qn)
		{
		case '1':
		{
			char c;
			int k = 0;
			char A1[3][4] = { { 'A', 'B', 'C', 'G' }, { 'E', 'F', 'G', 'H' }, { 'I', 'J', 'K', 'L' } };
			cout << "Values in Grid are: " << endl;
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 4; j++) {
					cout << A1[i][j] << " ";
				}
				cout << endl;
			}
			cout << "Enter character which you want to search : ";
			cin >> c;
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 4; j++) {
					if (A1[i][j] == c) {
						k += 1;
					}
				}
			}
			cout << "Ocuurence of '" << c << "' is  :" << k << endl;
			system("pause");
			return 0;
		}
		break;

		case '2':
		{
			int A2[5][5];
			const int rows = 5;
			const int columns = 5;

			cout << "Enter the elements  of 2D Array : " << endl;
			takeInput(A2, rows, columns);
			cout << endl;
			cout << "Matrix : " << endl;
			printMatrix(A2, rows, columns);
			cout << endl;
			cout << endl;
			cout << "Transpose of Matrix : " << endl;
			takeTranspose(A2, rows, columns);
		}
		break;

		case '3':
		{
			char src[3][50] = {
				"HELLO WORLD",
				"hello world",
				"12345 67899"
			};
			char dest[50] = {};

			int num = sizeof(src) / sizeof(src[0]);

			printMenu(src, num);

			int choice;
			cout << "Enter your choice (1-" << num << "): ";
			cin >> choice;

			if (choice >= 1 && choice <= num) {
				copyStr(dest, src[choice - 1]);
				cout << "String copied successfully!" << endl;
				cout << "Source:      " << src[choice - 1] << endl;
				cout << "Destination: " << dest << endl;
			}
			else {
				cout << "Invalid choice. Please enter a number between 1 and " << num << "." << endl;
			}
		}
			break;

		case '4':
		{
			char ins[3][50];

			cout << "Enter your 2D array :" << endl;
			for (int i = 0; i < 3; i++) {
				cin.getline(ins[i],50);
			}

			cout << "\n Your 2D array is : " << endl;
			for (int i = 0; i < 3; ++i) {
				cout << ins[i] << endl;
			}

			cor(ins);

			cout << "\nCorrected Strings : " << endl;
			for (int i = 0; i < 3; ++i) {
				cout << ins[i] << endl;
			}
		}
			break;

		case '5':
		{
			int arr[3][5];

			cout << "Enter 15 integers for the 2D array (5 elements in each row ):" << endl;
			for (int i = 0; i < 3; ++i) {
				cout << "Row " << (i + 1) << ": ";
				for (int j = 0; j < 5; ++j) {
					cin >> arr[i][j];
				}
			}

			cout << "\nOriginal 2D Array:" << endl;
			for (int i = 0; i < 3; ++i) {
				for (int j = 0; j < 5; ++j) {
					cout << arr[i][j] << " ";
				}
				cout << endl;
			}

			int n;
			cout << "\nEnter the row index to sort (0 to 2): ";
			cin >> n;

			sortRow(arr, n);

			cout << "\n2D Array After Sorting Row " << n << ":" << endl;
			for (int i = 0; i < 3; ++i) {
				for (int j = 0; j < 5; ++j) {
					cout << arr[i][j] << " ";
				}
				cout << endl;
			}
		}

			break;
		case '6':
		{
			char strings[3][100];
			cin.getline(strings[0], 100);
			for (int i = 0; i < 3; ++i) {
				cout << "Enter string " << i + 1 << ": ";
				cin.getline(strings[i], 100);
				
			}

			reverseEachString(strings);

			cout << endl << "Reversed strings:" << endl;
			for (int i = 0; i < 3; ++i) {
				if (strings[i][0] != '\0') {
					cout << strings[i] << endl;
				}
			}
		}

			break;

		case '7':
		{
			char strings[3][100];
			readStrings(strings);
			printStrings(strings, "Original");
			rotateEachString(strings);
			printStrings(strings, "Rotated");
		}
			break;
		case '8':
		{
			char A8[3][100];

			readStrings(A8);

			printStrings(A8, "Original");

			int n;
			cout << "\nEnter the row index you want to sort(0-2) : \t";
			cin >> n;

			cin.ignore(10000, '\n');

			sortRow(A8, n);

			printStrings(A8, "Sorted");
		}
		
			break;

		case '9':
		{
			int size;

			cout << "Enter the size of the square matrix (n*n) : \t";
			cin >> size;

			if (size <= 0 || size > 100) {
				cout << "Invalid matrix size." << endl;
				return 1; 
			}

			int matrix[100][100];

			cout << "Enter the elements of the matrix:" << endl;
			for (int i = 0; i < size; ++i) {
				for (int j = 0; j < size; ++j) {
					cout << "Element at position (" << i + 1 << ", " << j + 1 << "): ";
					cin >> matrix[i][j];
				}
			}

			cout << "\nThe input matrix is:\n";
			displayMatrix(matrix, size);

			if (isSymmetric(matrix, size)) {
				cout << "\nThe matrix is symmetric." << endl;
			}
			else {
				cout << "\nThe matrix is not symmetric." << endl;
			}
		}

			break;
		default:
			cout << "Wrong Input ! " << endl;

		}
		cout << "\nPress 1 if you want to ReRun this programe\n Press any other key to exit\t";
		cin >> choice;
	} while (choice == 1);

	system("pause");

	return 0;
}
