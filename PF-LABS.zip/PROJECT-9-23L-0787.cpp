#include <iostream>
#include<string>
using namespace std;

int power(double a, int b) {
	if (b == 1)
		return a;
	else
		return (a * power(a, b - 1));
}

double rollno = 787;

int add(int n1, int n2) {
	int c;
	c = n1 + n2;
	c = c + rollno;
	return c;
}
int subtract(int n1, int n2) {
	int c;
	c = n1 - n2;
	c = c + rollno;
	return c;
}
int multiply(int n1, int n2) {
	int c;
	c = n1 * n2;
	c = c + rollno;
	return c;
}
int devide(int n1, int n2) {
	int c;
	c = n1 / n2;
	c = c + rollno;
	return c;
}
int fib(int n) {
	if (n <= 1)
		return n;
	return fib(n - 1) + fib(n - 2);
}
void  calculategrade(int marks, char& grades) {
	if (marks > 80 && marks<=100)
	{
		grades = 'A';
	}
	else if (marks <= 80 && marks > 65)
	{
		grades = 'B';
	}
	else if (marks <= 65 && marks > 50)
	{
		grades = 'C';
	}
	else if (marks <= 50 && marks >=0)
	{
		grades = 'F';
	}
	else
	{
		cout << "Error ! Please Enter velid Percentage ! " << endl;
	}
}
void printdiagnol(int limit) {
	
	for (int i = 1; i <= limit; i++) {
		for (int j = 0; j < i; j++)
			cout << "  ";
		if (i % 3 != 0)
			cout << i;
		else
			cout << " ";
		cout << endl;
	}
}
void printunique(int A1[], int n) {
	bool unique = 1;
	for (int i = 0; i < n; i++) {
		unique = 1;
		for (int j = 0; j < n; j++) {
			if (i != j && A1[i] == A1[j])
				unique = 0;
		}
		if (unique == 1)
			cout << A1[i] << "  ";
	}
}
void cynicallyrotate(int A2[], int s, int d) {
	int array2[100];
	for (int i = 0; i < d; i++) {
		array2[i] = A2[i];
	}
	for (int i = 0; i < s - d; i++) {
		A2[i] = A2[i + d];
	}
	for (int i = s - d; i < s; i++) {
		A2[i] = array2[i - (s - d)];
	}
}
void reversearray( char A3[], int s2) {
	int i;
	char t = 0;
	for ( i = 0; i < s2 / 2; i++) {

		t = A3[s2 - 1 - i];
		A3[s2 - 1 - i] = A3[i];
		A3[i] = t;
	}
	for ( i = 0; i < s2; i++) {
		cout << A3[i] ;
	}
}
int Search(int A5[], int s4, int a) {
	for (int i = 0; i < s4; i++) {
		if (A5[i] == a) {
			return i;
		}
	}
	return -1;
}
bool PalindromeString(char A4[], int s3) {
	char t = 0;
	int i = 0, j = s3 - 1;
	while (i < j) {
		if (A4[i] != A4[j]) {
			cout << "The string is not a palindrome.\n       AND \nThe reverse of input is : " << endl;
			for (int z = 0; z < s3 / 2; z++) {

				t = A4[s3 - 1 - z];
				A4[s3 - 1 - z] = A4[z];
				A4[z] = t;
			}
			for (int z = 0; z < s3; z++) {
				cout << A4[z];
			}
			return false;
		}
		i++;
		j--;
	}
	cout << "The string is a palindrome.\n          AND \nThe reverse of input is : " << endl;
	for (int z = 0; z < s3 / 2; z++) {

		t = A4[s3 - 1 - z];
		A4[s3 - 1 - z] = A4[z];
		A4[z] = t;
	}
	for (int z = 0; z < s3; z++) {
		cout << A4[z];
	}
	return true;	
}


int main()
{
	int choice = 0;
	char Qn;
	do
	{
		cout << "Please Enter QN: 1, 2, 3, 4, 5, 6, 7, 8, 9, a\t";
		cin >> Qn;
		switch (Qn)
		{
		case'1':
		{
			double a;
			int d, b;
			cout << "Enter the base number : " << endl;
			cin >> a;
			cout << "Enter the exponent (default is 2 if omitted) (please enter '=<0' if you want omit) !: " << endl;
			cin >> b;
			if (b <= 0)
			{
				b = 2;
				d = power(a, b);
			}
			else if (b > 0)
			{
				d = power(a, b);
			}

			cout << "(" << a << ") raised to the power (" << b << ") is : (" << d << ")" << endl;

		}

		break;
		case'2': {
			int n1, n2;
			char choic;
			cout << "1. Addition " << endl;
			cout << "2. Subtraction " << endl;
			cout << "3. Multiplication " << endl;
			cout << "4. Divisison " << endl;
			cout << "5. Exit " << endl;
			cout << "Enter your choice : ";
			cin >> choic;
			switch (choic)
			{
			case'1': {
				cout << "Enter the first number : " << endl;
				cin >> n1;
				cout << "Enter the second number : " << endl;
				cin >> n2;
				cout << "Result :" << add(n1, n2);

			}
				   break;
			case'2': {
				cout << "Enter the first number : " << endl;
				cin >> n1;
				cout << "Enter the second number : " << endl;
				cin >> n2;
				cout << "Result :" << subtract(n1, n2);
			}
				   break;
			case'3': {
				cout << "Enter the first number : " << endl;
				cin >> n1;
				cout << "Enter the second number : " << endl;
				cin >> n2;
				cout << "Result :" << multiply(n1, n2);
			}
				   break;
			case'4': {
				cout << "Enter the first number : " << endl;
				cin >> n1;
				cout << "Enter the second number : " << endl;
				cin >> n2;
				cout << "Result :" << devide(n1, n2);
			}
				   break;
			case '5': {
				cout << "Calculater Closed! " << endl;
				system("pause");
			}
					break;
			default: {
				cout << "Please enter a valid number ! " << endl;
			}
				   break;
			}

		}
			   break;

		case '3':
		{
			int n;
			cout << "Enter the number to which you want the fabonacci sereies : " << endl;
			cin >> n;

			for (int i = 0; i < n; i++) {
				cout << fib(i) << " ";
			}
		}
		break;

		case '4': {
			int marks = 0;
			char grades;

			do {
				cout << "Enter your marks ( or -1 to exit the program ): ";
				cin >> marks;
				if (marks == -1)
					break;
				else
					calculategrade(marks, grades);
				cout << "Grade:" << grades << endl;


			} while (marks != -1);
		}

				break;

		case '5':
		{
			int limit = 0;
			cout << "Please Enter the limit of diagnol (Greater than 0!) : " <<" (" ;
			cin >> limit;
			 printdiagnol(limit);
		}
		break;

		case '6':
		{
			int A1[100], n;
		cout << "Please Enter the Array size :" << endl;
		cin >> n;
		cout << "Please Enter the numbers : " << endl;
		for (int i = 0; i < n; i++) {
			cin >> A1[i];
		}
		cout << "Unique Elements : ";
		printunique(A1, n);
		}
			break;

		case '7':
		{
			int A2[100], s, d;
			cout << "Please Enter the Array size : " << endl;
			cin >> s;
			cout << "Please Enter the numbers : " << endl;
			for (int i = 0; i < s; i++) {
				cin >> A2[i];
			}
			cout << "Please Enter the Factor of rotation (d) : " << endl;
			cin >> d;
			cynicallyrotate(A2, s, d);
			for (int i = 0; i < s; i++) {
				cout << "  " << A2[i];
			}
		}
			break;
		case'8': {
			char A3[500];
			int s2, d;
			cout << "Please Enter the number of alphabets you want to enter : " << endl;
			cin >> s2;
			cout << "Please Enter the word  without space  : " << endl;
			for (int i = 0; i < s2; i++) {
				cin >> A3[i];
			}
			reversearray(A3, s2); 
		}

			   break;
		case'9':
		{
			int A5[100];
			int s4, a;

			cout << "Please Enter the Array size : " << endl;
			cin >> s4;

			cout << "Please Enter the elements of the array: " << endl;
			for (int i = 0; i < s4; i++) {
				cin >> A5[i];
			}

			cout << "Enter the number that you wanted to search: " << endl;
			cin >> a;

			int result = Search(A5, s4, a);
			if (result != -1) {
				cout << "Number found at index : (" << result <<") .";
			}
			else {
				cout << "Number not found in the input array." << endl;
			}
		}
			break;
		case'a':
		{
			char A4[500];
			int s3, d;
			cout << "Please Enter the number of alphabets you want to enter : " << endl;
			cin >> s3;
			cout << "Please Enter the word  without space  : " << endl;
			for (int i = 0; i < s3; i++) {
				cin >> A4[i];
			}
			PalindromeString( A4, s3);
		}
			break;


		default:
			cout << "Wrong Input \n";

		}
		cout << "\nPress 1 if you want to ReRun this programe\n Press any other key to exit\n";
		cin >> choice;
	} while (choice == 1);

	system("pause");

	return 0;
}
