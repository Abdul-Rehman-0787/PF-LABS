#include <iostream>
#include <string> 

using namespace std;

//void main() {
//    cout << "Hello! Welcome in the world of Programming" << endl;
//    system("pause");
//}
                                         //(2)
//void main(){
//	int num1 = 0;
//	int num2 = 0;
//	int sum = 0;
//	int product = 0;
//	int subtraction = 0;
//	int devision = 0;
//
//	cout << "Enter  first number: " << endl;
//	cin >> num1;
//
//	cout << "Enter second number: " << endl;
//	cin >> num2;
//	sum = num1 + num2;
//
//	cout << "The sum is: " << sum << endl;
//
//	product = num1 * num2;
//	cout << "The product  is :" << product << endl;
//
//	subtraction = num1 - num2;
//	cout << "The subtration is: " << subtraction << endl;
//	devision = num1 / num2;
//	cout << "The division is: " << devision << endl;
//	system("Paues");
//}
                               //(3)
//void main(){                              
//	float F=0;
//	float C=0;
//
//
//	cout<<"Enter the temperature in Fahrenhied: "<<endl;
//	cin>> F;
//
//	C=(F-32)*(5.0/9.0);
//	cout<<"the temperature in celceus is: "<<C<<endl;
//	system ("pause");
//	}
                                     //(4)
//void main(){
//		string Name;
//		string Rollno ;
//		cout<<"Enter your name"<<endl;
//		cin >> Name;
//		cout << endl;
//		cout<<"Enter your Roll no. :"<<endl;
//		cin>>Rollno ;
//		cout<< "Your name  is: " <<Name<<endl;
//		cout << "Your Roll no. is :" << Rollno << endl; 
//			int i = 0, var = 5;
//		i = i + 1;
//		cout << "*" << i << "=" << var * i << "\n";
//		i = i + 1;
//		cout << "*" << i << "=" << var * i << "\n";
//		i=i+1;
//		cout<<"*"<<i<<"="<<var*i<<"\n";
//		i=i+1;
//		cout<<"*"<<i<<"="<<var*i<<"\n";
//		i=i+1;
//		cout<<"*"<<i<<"="<<var*i<<"\n";
//		i=i+1;
//		cout<<"*"<<i<<"="<<var*i<<"\n";
//		i=i+1;
//		cout<<"*"<<i<<"="<<var*i<<"\n";
//		i=i+1;
//		cout<<"*"<<i<<"="<<var*i<<"\n";
//		i=i+1;
//		cout<<"*"<<i<<"="<<var*i<<"\n";
//		i=i+1;
//		cout<<"*"<<i<<"="<<var*i<<"\n";
//		cout<<"programming "<<endl;
//		cout<<"is great "<<endl;
//		cout<<"fun : d"<<endl; 
//		cout<<"programming\n";
//			cout<<"is great\n";
//			cout<<"fun : d\n";
//				system("pause");
//			}
			   