#include <iostream>
using namespace std;

int main()
{
	int choice = 0;
	char Qn;
	do
	{
		cout << "Please Enter QN:  1, 2, 3, 4, 5, 6, 7, 8, 9, a" << endl;
		cin >> Qn;
		switch (Qn)
		{
		case '1': {
			int i, n, l=9, b, c;
			int array[100];

			cout << "Enter total number of elements(1 to 100): ";
			cin >> n;
			cout << endl;

			for (i = 0; i < n; ++i) {
				cout << "Enter Number " << i + 1 << " : ";
				cin >> array[i];
			}
			for (i = 0; i < n; i++)
			{
				if (array[0] < array[i]) {
					array[0] = array[i];
					l = 1;
				}
				else if (array[n-1-i]>array[n])
				{
					array[n] = array[n - 1 - i];
					l = 2;
				}
				else {
					l = 3;
				}
			}
			if (l == 1)
			{
				cout << "The array is in ascending order ." << endl;
			} 
			else if (l == 2) {
				cout << "The array is in descending order ." << endl;
			}
			else
			{
				cout << "The array has no order. " << endl;
			}

			for (i = 1; i < n; ++i) {

				if (array[0] < array[i])
					array[0] = array[i];
			}
			if (array[0] < array[1]) {
				b = array[1];
				c = array[0];
			}
			else {
				b = array[0];
				c = array[1];
			}
			for (int j = 2; j < n; j++) {

				if (array[j] > b) {
					c = b;
					b = array[j];
				}

				else if (array[j] > c && array[j] != b) {
					c = array[j];
				}
			}


			cout << "Largest element : " << array[0] << endl;
			cout << "Second Largest element : " << c << endl;

		}
				break;
		case '2': {
			int input[100], output[100], c, i;

			cout << "Enter number of elements in array : " << endl;
			cin >> c;

			cout << "Enter " << c << " numbers : " << endl;

			for (i = 0; i < c; i++) {
				cin >> input[i];
			}

			for (i = 0; i < c; i++) {
				output[i] = input[c - i - 1];
			}

			cout << "Reversed Array : ";
			for (i = 0; i < c; i++) {
				cout << output[i] << " ";
			}

		}
				break;
		case '3': 
		{
			int input[15], output[15], i;

			cout << "Enter 15 numbers in array : " << endl;

			for (i = 0; i < 15; i++) {
				cout << "Enter a numbers : " << endl;
				cin >> input[i];
			}

			for (i = 0; i < 15; i++) {
				output[i] = input[15 - i - 1];
			}

			cout << " Values in  Array in Reversed order are  : ";
			for (i = 0; i < 15; i++) {
				cout << output[i] << " ";
			}
		}

		
				break;

		case '4': 
		{
			int a[3], b[3], c[6], i, j;
			cout << "ENTER THE ELEMENTS OF COMPOSITE ARRAY : " << endl;

			for (i = 0; i < 6; i++)
			{
				cin >> c[i];
			}
			cout << endl;
			cout << " THE ELEMENTS OF COMPOSITE ARRAY  ARE : " << endl;

			for (i = 0; i < 6; i++)
			{
				cout << c[i] << " ";
			}
			cout << endl;

			for (i = 0, j = 0; j < 3; i++, j++)
			{
				a[i] = c[j];
				b[i] = c[i + 3];
			}

			cout << "PRINT THE ELEMENTS OF ARRAY1 : " << endl;
			for (i = 0; i < 3; i++)
			{
				cout << a[i] << " ";
			}
			cout << endl;
			cout << "PRINT THE ELEMENTS OF ARRAY2 : " << endl;
			for (i = 0; i < 3; i++)
			{
				cout << b[i] << " ";
			}



		}
				break;

		case '5': 
		{
			int i, A[10], p, n;
			cout << "Enter array size ( Max:10 ) :: " << endl;
			cin >> n;
			cout << "Enter array elements :: " << endl;

			for (i = 0; i < n; i++)
			{
				cout << endl;
				cout << "Enter arr[" << i << "] Element :: ";
				cin >> A[i];
			}
			cout << endl;
			cout << "Stored Data in Array :: " << endl;
			cout << endl;

			for (i = 0; i < n; i++)
			{
				cout << " " << A[i] << " ";
			}
			cout << endl << endl;
			cout << "Enter position to Delete number :: ";
			cin >> p;

			if (p > n)
			{
				cout << endl;
				cout << "This is out of range." << endl;
			}
			else
			{
				--p;
				for (i = p; i <= n - 1; i++)
				{
					A[i] = A[i + 1];
				}
				cout << "New Array is : " << endl;

				for (i = 0; i < n - 1; i++)
				{
					cout << " " << A[i] << " ";
				}

			}
			cout << endl;

		}
				break;

		case '6': 
		{
			int i, n;
			double sum = 0, average = 0;

			cout << "Enter the number integers you want in an array in range (1 to 100) : ";
			cin >> n;

			int arr[100];

			cout << "Enter " << n << " integers into an array :" << endl;

			for (i = 0; i < n; i++)
			{
				cin >> arr[i];
			}
			cout << endl;
			cout << "The Elements of the Array are: " << endl;

			for (i = 0; i < n; i++)
			{
				cout << arr[i] << endl;
				sum += arr[i];
			}

			average = sum / n;

			cout << "The Sum of the Elements of the Array is : " << sum << endl;

			cout << "The Average of the Elements of the Array is : " << average << endl;



			int  j, large, small;

			large = small = arr[0];

			for (j = 1; j < n; ++j)
			{
				if (arr[j] > large)
					large = arr[j];

				if (arr[j] < small)
					small = arr[j];
			}

			cout << "The smallest element is " << small << endl;
			cout << "The largest element is " << large << endl;


			break;
		}
		case '7': 

			{
				int n, num;
				cout << "Enter the size of array: " << endl;
				cin >> n;

				int array[500];
				cout << "Enter array elements: " << endl;
				for (int i = 0; i < n; i++) {
					cin >> array[i];
				}
				cout << "Enter the number whose pairs are to be found: " << endl;
				cin >> num;
				for (int i = 0; i < n - 1; i++) {
					for (int j = i + 1; j < n; j++) {
						if (array[i] + array[j] == num)
							cout << array[i] << " and " << array[j] << endl;
					}
				}

			}
			break;
		case'8': 
			{
				int arr[100], i, n;
				cout << "Enter Size of an Array: ";
				cin >> n;

				cout << "Enter your Numbers : " << endl;
				for (i = 0; i < n; i++) {
					cin >> arr[i];
				}
				cout << "Array without any duplicates  : ";
				for (i = 0; i < n; i++)
				{
					for (int j = i + 1; j < n;)
					{
						if (arr[j] == arr[i])
						{
							for (int k = j; k < n; k++)
							{
								arr[k] = arr[k + 1];
							}
							n--;
						}
						else
							j++;
					}
				}

				for (i = 0; i < n; i++)
				{
					cout << arr[i] << " ";
				}

			}
			break;
		case'9': 
		{
			int a, b, c, i=0, l=0,  j=0, k=0;
			int array1[100] ;
			int array2[100] ;
			int array3[100] ;
			cout << "Enter the number of intigers for array 1 : " << endl;
			cin >> a;
			cout << "Enter Array 1 : " << endl;
			for ( i = 0; i < a; i++) {
				cin >> array1[i];
			}
			cout << "Enter the number of intigers for array 2 : " << endl;
			cin >> b;
			cout << "Enter Array 2 : " << endl;
			for ( i = 0; i < b; i++) {
				cin >> array2[i];
			}
			cout << "Enter the number of intigers for array 3 : " << endl;
			cin >> c;
			cout << "Enter Array 3 : " << endl;
			for ( i = 0; i < c; i++) {
				cin >> array3[i];
			}
			cout << "Common elements of the sorted arrays are : " << endl;
			for ( l = 0; l < a ; l++)
			{
				for (j = 0; j < b; j++) {
					for ( k = 0; k < c;k++){
						if (array1[l] == array2[j] && array3[k] == array1[l])
						{
							cout << array1[l] << " ";
						}
						
					}
				}
			}			
		}
			   break;
		case'a':
		{
			int A1[10], A2[10], A3[10];
			cout << "Enter the elements for ARRAY-1 (A1) : " << endl;
			for (int i = 0; i < 10; i++)
			{
				cin >> A1[i];
			}
			cout << "Enter the elements for ARRAY-2 (A2) : " << endl;
			for (int j = 0; j < 10; j++)
			{
				cin >> A2[j];
			}
			cout << "A3 : ";
			for (int k = 0; k < 10; k++)
			{
				if ( (A1[k] != A2[0])  && (A1[k] != A2[1]) && (A1[k] != A2[2]) && (A1[k] != A2[3]) && (A1[k] != A2[4]) && (A1[k] != A2[5]) && (A1[k] != A2[6]) && (A1[k] != A2[7]) && (A1[k] != A2[8]) && (A1[k] != A2[9]) )
				{
					cout << A1[k] << " ";
					A3[k] = A1[k];
				}
				else if (A1[k] == A2[k]) {
					A3[k] = 0;
				}
			}

		}
		break;
		default:
			cout << "Wrong Input ! " << endl;

		}
			   cout << "\nPress 1 if you want to ReRun this programe\n Press any other key to exit" << endl;
			   cin >> choice;
		} while (choice == 1);

		system("pause");

		return 0;
		}
