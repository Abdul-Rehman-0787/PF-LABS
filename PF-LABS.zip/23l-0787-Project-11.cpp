//23L-0787     1J2                  ABDUL-REHMAN NASEER 
#include <iostream>
#include <climits>
using namespace std;

int Trace(int data[][3]);
void lookupName(const char* targetName, const char* names[], const char* phoneNumbers[], int size);
void UpperHalf(int A6[100][100], int N);
void ReverseString(char input[]);
int CountCharacters(const char input[]);
bool Exists(int A8[][6], int A9[][3]);

int main(){

    int choice = 0;
    char Qn;
    do
    {
        cout << "Please Enter QN: 1, 2, 3, 4, 5, 6, 7, 8, 9\t\t";
        cin >> Qn;
        switch (Qn)
        {
        case '1':
        {
                char A1[100];
                cout << "Enter a sentence : ";
                cin.getline(A1, 100);
                int length = 0;
                for (int i = 0; A1[i] != '\0'; ++i) {
                    if (A1[i] != ' ') {
                        ++length;
                    }
                }
                cout << "Total characters are : " << length << endl;
        }
            break;

        case '2':
        {
                char A2[1000];
                cout << "Enter a sentence (ending with a full stop): ";
                cin.getline(A2, 1000, '.');
                int A3[1000];
                int ABD = 0;
                int a = INT_MAX;
                char* word=0;
                for (char* ptr = A2; *ptr != '\0'; ++ptr) {
                    if (*ptr == ' ') {
                        ++ABD;
                        continue;
                    }
                    char* start = ptr;
                    while (*ptr != ' ' && *ptr != '\0') {
                        ++ptr;
                    }

                    int length = ptr - start;
                    A3[ABD] = length;

                    if (length < a) {
                        a = length;
                        word = start;
                    }

                    if (*ptr == '\0') {
                        break;
                    }
                }
                cout << "Words and their lengths : ";
                for (int i = 0; i <= ABD; ++i) {
                    cout << A3[i] << " ";
                }
                cout << endl;
                cout << "Word with minimum length: " << string(word, a) << " (Length: " << a << ")" << endl;
        }
            break;
        case '3':
        {
                char c;
                char A4[1000];
                cout << "Enter a character: ";
                cin >> c;
                cout << "Enter a sentence: ";
                cin >> A4;
                int a = 0, b = 0;
                while (A4[a] != '\0') {
                    if (A4[a] != c) {
                        A4[b] = A4[a];
                        ++b;
                    }
                    ++a;
                }
                A4[b] = '\0'; 
                cout << "Updated sentence: " << A4 << endl;
        }
            break;

        case '4':
        {
            int A5[3][3];
            cout << "Enter the elements of the 3 x 3  matrix : " << endl;
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {
                    cout << "Matrix[" << i << "][" << j << "]: ";
                    cin >> A5[i][j];
                }
            }
            cout << endl << "The matrix is : " << endl;
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {
                    std::cout << A5[i][j] << " ";
                }
                cout << endl;
            }
            int traceValue = Trace(A5);
            cout << endl << "The sum of diagnols of the matrix is : " << traceValue << endl;
        }
            break;

        case '5':

            
             {
                const char* names[5] = { "Michael Myers", "Ash Williams", "John Wick", "Jack Sparrow", "Tony Stark" };
                const char* phoneNumbers[5] = { "333-8000", "333-2323", "555-1234", "555-5678", "999-9999" };

                char targetName[50];
                cout << "Enter a name to look up: ";
                cin.getline(targetName, sizeof(targetName));
                lookupName(targetName, names, phoneNumbers, 5);

            }

            break;

        case '6':
        {
            int N=0;
            cout << "Please enter the size of row and column : ";
            cin >> N;
            int A6[100][100];
            cout << "Enter the elements of the " << N << "x" << N << " array : " << endl;
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < N; ++j) {
                    cout << "Array[" << i << "][" << j << "]: ";
                    cin >> A6[i][j];
                }
            }
            cout << endl << "Upper half of the array : " << endl;
            UpperHalf(A6,N);
        }
            break;

        case '7':
        {
             
            char input[1000];
            cin.ignore();
            cout << "Enter the string: ";
            cin.getline(input, 1000);
            ReverseString(input);
            cout << "Reversed string: " << input << endl;

        }
            break;
        case '8':
        {
            char input[1000];
            cin.ignore();
            cout << "Enter a string: ";
            cin.getline(input, 1000);
            int characterCount = CountCharacters(input);
            cout << "Number of characters: " << characterCount << endl;
        }
            break;

        case '9':
        {
            int A8[6][6];
            int A9[3][3];
            cout << "Enter the elements of the data array (6x6) : " << endl;
            for (int i = 0; i < 6; ++i) {
                for (int j = 0; j < 6; ++j) {
                    cout << "Data[" << i << "][" << j << "]: ";
                    cin >> A8[i][j];
                }
            }

            cout << "Enter the elements of the pattern array (3x3) : " << endl;
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {
                    cout << "Pattern[" << i << "][" << j << "]: ";
                    cin >> A9[i][j];
                }
            }
            if (Exists(A8, A9)) {
                cout << "Pattern exists in the data array." << endl;
            }
            else {
                cout << "Pattern does not exist in the data array." << endl;
            }

        }
            break;
        default:
            cout << "Wrong Input ! " << endl;

        }
        cout << "\nPress 1 if you want to ReRun this programe\n Press any other key to exit" << endl;
        cin >> choice;
    } while (choice == 1);

    system("pause");

    return 0;
}
int Trace(int data[][3]) {
    int trace = 0;

    for (int i = 0; i < 3; ++i) {
        trace += data[i][i];
    }

    return trace;
}
void lookupName(const char* targetName, const char* names[], const char* phoneNumbers[], int size) {
    for (int i = 0; i < size; ++i) {
        if (strcmp(targetName, names[i]) == 0) {
            cout << "Phone number for " << targetName << ": " << phoneNumbers[i] << endl;
            return;
        }
    }

    cout << "Name not found in the phone book." << endl;
}
void UpperHalf(int A6[100][100], int N) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (j >= i) {
                cout << A6[i][j] << " ";
            }
            else {
                cout << "  ";
            }
        }
        cout << endl;
    }
}
void ReverseString(char input[]) {
    int length = strlen(input);
    int start = 0;
    for (int i = 0; i <= length; ++i) {
        if (input[i] == ' ' || input[i] == '\0') {
            for (int j = start, k = i - 1; j < k; ++j, --k) {
                char temp = input[j];
                input[j] = input[k];
                input[k] = temp;
            }
            start = i + 1;
        }
    }
}

int CountCharacters(const char input[]) {
    return strlen(input);
}

bool Exists(int A8[][6], int A9[][3]) {
    for (int i = 0; i <= 6 - 3; ++i) {
        for (int j = 0; j <= 6 - 3; ++j) {
            bool found = true;
            for (int m = 0; m < 3; ++m) {
                for (int n = 0; n < 3; ++n) {
                    if (A8[i + m][j + n] != A9[m][n]) {
                        found = false;
                        break;
                    }
                }
                if (!found) {
                    break;
                }
            }
            if (found) {
                return true;
            }
        }
    }
    return false;
}