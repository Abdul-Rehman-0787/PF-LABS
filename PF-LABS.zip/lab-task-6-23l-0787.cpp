#include <iostream>
using namespace std;

int main() {
    int choice = 0;
    char Qn;
    do
    {
        cout << "Please Enter QN: 1, 2, 3, 4, 5, 6, 7" << endl;
        cin >> Qn;
        switch (Qn)
        {
        case '1':
        {int n;
        cout << "Enter the length of the series : ";
        cin >> n;
        if (n <= 0) {
            cout << "Invalid length ! Please enter a positive integer." << endl;
        }
        else
        {
            int a = 0, b = 1, c = 0;
            if (n > 5) {
                cout << "0 1 1 0 1 ";
                for (int i = 0; i < (n - 5); i++) {
                    if (i % 2 == 0) {
                        c = a - b;
                    }
                    else {
                        c = a + b;
                    }
                    cout << c << " ";
                    a = b;
                    b = c;
                }
                cout << endl;
            }

            else
            {
                cout << "Please enter a number greater than 5 " << endl;
            }
        }}
        break;
        case '2':
        {
            int n;
            cout << "Enter a positive integer: ";
            cin >> n;
            if (n <= 0) {
                cout << "Invalid number ! Please enter a positive number ." << endl;
            }
            else
            {
                int j = 0;
                cout << n << " ";

                while ((n != 3) && (j < 40)) {
                    if (n % 2 == 0) {
                        if (n < 10) {
                            cout << "(even and less than 10 ,multiply by 5) " << endl;
                            n *= 5;
                        }
                        else {
                            cout << "(even and greater 10,divide by 2)" << endl;
                            n /= 2;
                        }
                    }
                    else {
                        cout << " ( odd,multiply by 3 and add 1)" << endl;
                        n = 3 * n + 1;
                    }
                    cout << n << " ";
                    j++;
                }
                cout << endl;
            }
        }
        break;
        case '3':
        {
            int n;
            cout << "Enter an integer n: ";
            cin >> n;

            for (int i = 1; i <= n; i++) {
                int d = 0;
                for (int j = 1; j <= i; j++) {
                    if (i % j == 0) {
                        d++;
                    }
                }
                if (d % 2 == 0) {
                    cout << i << " EVEN : ";
                }
                else {
                    cout << i << " ODD  : ";
                }
                for (int j = 1; j <= i; j++) {
                    if (i % j == 0) {
                        cout << j << " ";
                    }
                }

                cout << endl;
            }


        }
        break;
        case '4':
        {
            int n;
            cout << "Enter a number: ";
            cin >> n;
            bool isPrime = true;
            if (n <= 1) {
                isPrime = false;
            }
            else {
                for (int i = 2; i <= sqrt(n); ++i) {
                    if (n % i == 0) {
                        isPrime = false;
                        break;
                    }
                }
            }

            if (isPrime) {
                int p = 1;
                int t = n;
                while (t > 0) {
                    int digit = t % 10;
                    p *= digit;
                    t /= 10;
                }
                cout << "The number is prime. Product of digits: " << p << endl;
            }
            else if (n % 2 == 0) {
                int r = 0;
                int t = n;
                while (t > 0) {
                    int digit = t % 10;
                    r = r * 10 + digit;
                    t /= 10;
                }
                cout << "The number is even but not prime. Reversed digits: " << r << endl;
            }
            else {
                int sum = 0;
                int t = n;
                while (t > 0) {
                    int digit = t % 10;
                    sum += digit;
                    t /= 10;
                }
                cout << "The number is odd but not prime. Sum of digits: " << sum << endl;
            }

            
        }
            break;

        case '5':        
        {
            int matrix[3][3];
            int sumOfRows[3] = { 0 };
            int sumOfCols[3] = { 0 };
            int sumOfDiags[2] = { 0 };
            cout << "Enter elements of 3x3 matrix (row by row) : ";
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    cin >> matrix[i][j];
                    sumOfRows[i] += matrix[i][j];
                    sumOfCols[j] += matrix[i][j];
                    if (i == j) sumOfDiags[0] += matrix[i][j];
                    if (i + j == 2) sumOfDiags[1] += matrix[i][j];
                }
            }
            bool isMagicSquare = true;
            for (int i = 1; i < 3; i++) {
                if (sumOfRows[i] != sumOfRows[0] || sumOfCols[i] != sumOfCols[0]) {
                    isMagicSquare = false;
                    break;
                }
            }
            if (sumOfDiags[0] != sumOfRows[0] || sumOfDiags[1] != sumOfRows[0]) isMagicSquare = false;

            if (!isMagicSquare) {
                cout << "The 3x3 matrix is not a magic square." << endl;
            }
            else {
                cout << "The 3x3 matrix is a magic square." << endl;

                int subMatrices[2][2] = {
                    {matrix[0][0] + matrix[0][1] + matrix[1][0] + matrix[1][1], matrix[0][1] + matrix[0][2] + matrix[1][1] + matrix[1][2]},
                    {matrix[1][0] + matrix[1][1] + matrix[2][0] + matrix[2][1], matrix[1][1] + matrix[1][2] + matrix[2][1] + matrix[2][2]}
                };

                int sum = subMatrices[0][0] + subMatrices[0][1];

                if (subMatrices[1][0] + subMatrices[1][1] == sum && subMatrices[0][0] + subMatrices[1][0] == sum && subMatrices[0][1] + subMatrices[1][1] == sum) {
                    cout << "The matrix formed by the sum of each 2x2 sub-matrix is also a magic square." << endl;
                }
                else {
                    cout << "The matrix formed by the sum of each 2x2 sub-matrix is not a magic square." << endl;
                }
            }
        }

            break;

        case '6': {
            int n;

            cout << "Enter the value of n : ";
            cin >> n;

            cout << "Numbers up to " << n << " which are equal to half the sum of their divisors : " << endl;

            for (int i = 1; i <= n; ++i) {
                int divisorSum = 0;
                for (int j = 1; j <= i / 2; ++j) {
                    if (i % j == 0) {
                        divisorSum += j;
                    }
                }

                if (i == divisorSum / 2) {
                    cout << i << endl;
                }
            }
        }
            break;
            
        case '7':
        {
            int n, o;
            int r = 0;
            int s = 0;

            cout << "Enter a number: " << endl;
            cin >> n;

            o = n;
            if (n<=0)
            {
                cout << "Please enter a positve number : " << endl;
            }
            else
            {
                while (n > 0) {
                    int a = n % 10;
                    r = r * 10 + a;
                    n /= 10;
                }
                if (o == r) {
                    cout << "The number is a palindrome." << endl;
                    n = o;
                    int digits[10] = { 0 }; 

                    while (n > 0) {
                        int b = n % 10;
                        digits[b]++;
                        n /= 10;
                    }

                    for (int i = 0; i < 10; i++) {
                        while (digits[i] > 0) {
                            s = s * 10 + i;
                            digits[i]--;
                        }
                    }
                    int c = 0;
                    n = s;
                    while (n > 0) {
                        int digit = n % 10;
                        c = c * 10 + digit;
                        n /= 10;
                    }

                    if (s == c) {
                        cout << "The number formed by its digits in descending order '"<< s <<"' is also a palindrome." << endl;
                    }
                    else {
                        cout << "The number formed by its digits in descending order '"<< c <<"' is not a palindrome." << endl;
                    }
                }
                else {
                    cout << "The number is not a palindrome." << endl;
                }
            }
        }

            break;

        default:
            cout << "Wrong Input " << endl;

        }
        cout << "\nPress 1 if you want to ReRun this programe\n Press any other key to exit" << endl;
        cin >> choice;
        
    } while (choice == 1);


    system("pause");

    return 0;
}
        
    



