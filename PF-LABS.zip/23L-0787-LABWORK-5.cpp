
#include <iostream>
#include <cmath>
#include <string>
using namespace std;
int main()
{
	int choice = 0;
	char Qn;
	do
	{
		cout << "Please Enter QN: 1, 2, 3, 4, 5, 6, 7, 8, 9" << endl;
		cin >> Qn;
		switch (Qn)
		{
		case '1':
		{int a, b, c;
		cout << "enter your numbers " << endl;
		cin >> a >> b >> c;
		if ((a % 2 == 0 && b % 2 == 0) || (a % 2 == 0 && c % 2 == 0) || (b % 2 == 0 && c % 2 == 0))
		{
			if (a >= b && a >= c)
				cout << "Largest number: " << a;
			else if (b >= a && b >= c)
				cout << "Largest number: " << b;
			else
				cout << "Largest number: " << c;
		}
		if ((a % 2 != 0 && b % 2 != 0) || (a % 2 != 0 && c % 2 != 0) || (b % 2 != 0 && c % 2 != 0))
		{
			if (a >= b && a >= c)
				cout << "Largest number: " << a;
			else if (b >= a && b >= c)
				cout << "Largest number: " << b;
			else
				cout << "Largest number: " << c;
		}
		}

		break;

		case'2':
		{int n1, n2, n3, i, d, digits;
		double sum;
		cout << "enter your starting & ending points" << endl;
		cin >> n1 >> n2;
		if (n1 > n2)
		{
			n1 = n1 + n2;
			n2 = n1 - n2;
			n1 = n1 - n2;

		}
		cout << "Armstrong numbers between " << n1 << " and " << n2 << " are: " << endl;
		for (i = n1; i <= n2; i++)
		{
			n3 = 0;
			d = i;
			while (d > 0)

			{
				++n3;
				d /= 10;
			}

			sum = 0;
			d = i;

			while (d > 0)
			{
				digits = d % 10;
				sum = sum + pow(digits, n3);
				d /= 10;
			}
			if (sum == i)
			{
				cout << i << " , ";

			}
		}
		}
		break;

		case '3':
		{
			int age, salary;
			cout << "Enter your age ;" << endl;
			cin >> age;
			cout << "Enter your salary ;" << endl;
			cin >> salary;
			if ((age < 25 && salary>5000) || (age > 40 && salary < 3000))
			{
				cout << "Special Catagory" << endl;
			}
			else {
				cout << "You Basic" << endl;
			}
		}
		break;

		case '4':
		{int r1, r2;
		cout << "Enter the range of years : ";
		cin >> r1;
		cin >> r2;
		for (int r = r1; r <= r2; r++)
		{

			if (r % 400 == 0) {
				cout << r << " is a Leap Year" << endl;
			}

			else if (r % 100 == 0) {
				cout << r << " is not a Leap Year" << endl;
			}

			else if (r % 4 == 0) {
				cout << r << " is a Leap Year" << endl;
			}

			else {
				cout << r << " is not a Leap Year" << endl;
			}
		}}
		break;

		case '5':
		{int  number, rem, ans = 0;
		cout << "Enter your number: ";
		cin >> number;
		for (int j = 1; j < number; j++)
		{
			rem = number % j;
			if (rem == 0)
				ans = ans + j;
		}
		if (ans == number)
		{
			cout << number << " is a Perfect Number" << endl;
		}
		else
		{
			cout << number << " is not a Perfect Number" << endl;
		}
		}
		break;

		case '6':
		{int angle1;
		int angle2;
		int angle3;
		cout << "ENTER THE  FIRST ANGLES :" << endl;
		cin >> angle1;
		cout << "ENTER THE  SECOND ANGLES :" << endl;
		cin >> angle2;
		cout << "ENTER THE  THIRD ANGLES :" << endl;
		cin >> angle3;

		if (angle1 <= 0 || angle2 <= 0 || angle3 <= 0)
		{
			cout << "ALL ANGLES MUST BE POSITIVE" << endl;
		}
		else if (angle1 + angle2 + angle3 == 180) {
			cout << "A Triangle can be created using these angles" << endl;
		}
		else
		{
			cout << "A Triangle cannot be created using these angles" << endl;
		}
		cout << "THE END" << endl;
		}
		break;

		case '7': {
			int Code;
			cout << "Enter  the code" << endl;
			cin >> Code;
			if (Code > 64 && Code < 91) {
				cout << Code << "Represents an upper case English alphabet" << endl;
			}
			else if (Code > 96 && Code < 123) {
				cout << Code << "Represents a lower case English alphabet" << endl;
			}
			else if (Code > 47 && Code < 58) {
				cout << Code << "Represents a digit" << endl;
			}
			else if (Code < 128) {
				cout << Code << "Represents a special character" << endl;
			}
			else {
				cout << "DOES NOT REPRESENTS AN ASCII CHARACTER" << endl;
			}

			cout << "THE END" << endl;
		}
				break;
		case '8':
		{
			int enterednum;
			cout << "Enter your Number" << endl;
			cin >> enterednum;
			if (enterednum < 100000) {
				cout << "Your Entered Number is Less then SIX Digit Numbers" << endl;
			}
			else if (enterednum > 999999) {
				cout << "Your Entered Number is Greater then SIX Digit Number" << endl;
			}
			else
			{
				int numb1, numb2, numb3, numb4, numb5, numb6, numb7, numb8;
				numb1 = enterednum / 100000;
				numb2 = enterednum % 100000;
				numb2 = numb2 / 10000;
				numb3 = enterednum % 10000;
				numb3 = numb3 / 1000;
				numb4 = enterednum % 1000;
				numb4 = numb4 / 100;
				numb5 = enterednum % 100;
				numb6 = numb5 % 10;
				numb5 = numb5 / 10;
				numb7 = numb1 + numb2 + numb3 + numb4 + numb5 + numb6;
				numb8 = numb1 * numb2 * numb3 * numb4 * numb5 * numb6;
				cout << "THE SUM OF DIGITS OF GIVEN NUMBER IS : " << numb7 << endl;
				cout << "THE PRODUCT OF DIGITS OF GIVEN NUMBER IS : " << numb8 << endl;
			}
		}
			break;
			case '9':
			{
				int x, y, lx, ly, rx, ry;
				cout << "Enter X-Coordinate of Point P : " << endl;
					cin >> x;
					cout << "Enter Y-Coordinate of Point P : " << endl;
					cin >> y;
					cout << "Enter X-Coordinate of LEFT-TOP Corner P : " << endl;
					cin >> lx;
					cout << "Enter Y-Coordinate of LEFT-TOP Corner P : " << endl;
					cin >> ly;
					cout << "Enter X-Coordinate of RIGHT-BOTTOM Corner P : " << endl;
					cin >> rx;
					cout << "Enter Y-Coordinate of RIGHT-BOTTOM Corner P : " << endl;
					cin >> ry;
					if ((x <= rx) && (x >= lx)) {
						if ((y<=ry) && (y>=ly))
						{
							cout << "Your Given Point P Lies Inside the region Rectangle " << endl;
						}
					}
					else { cout << "Your Given Point P Does Not Lies Inside the region Rectangle" << endl; }
			}
			break;
					default:
						cout << "Wrong Input \n";
			
		}
		cout << "\nPress 1 if you want to Re-Run this programe\n Press any other key to exit" << endl;
		cin >> choice;
	} while (choice == 1);

	//system ("pause");


	return 0;
}