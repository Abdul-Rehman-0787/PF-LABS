#include <iostream>
using namespace std;

int main()
{
	int choice = 0;
	char Qn;
	do
	{
		cout << "Please Enter QN: 3, 4, 5, 6, 7\n";
		cin >> Qn;
		switch (Qn)
		{
		case '3':
			// put code for q3
			int a;
			int b;
			cout << "Enter your 1st number : " << endl;
			cin >> a;
			cout << "Enter your 2nd number : " << endl;
			cin >> b;
			int i;
			while (a != b) {
				if (a > b)
				{
					a -= b;
				}
				else
				{
					b -= a;
				}
			}
			cout << "HCF IS :  " << a << endl;
			break;

		case '4':
			// code to be executed if
			// expression is equal to constant2;
			int a, count = 1, c, d;
			while (count <= 500)
			{
				a = count;
				d = 0;

				while (a)
				{
					c = a % 10;
					d = d + (c * c * c);
					a = a / 10;
				}
				if (count == d)
				{
					cout << "%d is a armstrong number\n" << count << endl;
				}
				count++;
			}
			break;

		case '5':
			// put code for q5

			int J=1,i = 1;
			while (J <= 25) {
				cout << "The square root of " << i << " is " << sqrt(i) << endl;
				i += 2;
                J++;
				break;

		case '6':
			// code to be executed if
			// expression is equal to constant2;
			int a = 0;//total room
			int b = 0;//total floors
			int c = 0;//rooms on floor
			int  d = 0;//total occupied rooms
			float  percentage = 0.00;//percentOccupied 

			cout << "Enter number of floors: ";
			cin >> b;

			while (b < 1)
			{
				cout << "Number of floors must be at least 1. Please re-enter ";
				cin >> b;
			}

			for (int i = 1; i <= b; i++)
			{
				if (i != 13)
				{
					cout << "Enter the number of rooms on the floor ";
					cin >> c;

					while (c < 10)
					{
						cout << "Number of rooms on floor must be at least 10. Please re-enter ";
						cin >> c;
					}

					cout << "How many rooms are occupied? ";
					cin >> c;
					a += c;
					d += c;
				}
			}
			percentage = (d / a) * 100;


			cout << "The hotel has total of  : " << b << " floors" << endl;
			cout << "The hotel has total of :  " << a << " rooms" << endl;
			cout << "There are   : " << d << " rooms occupied" << endl;
			cout << "There are   : " << a - d << " empty rooms" << endl;
			cout << "Percentage of occupied rooms is  : " << percentage << "%" << endl;
			break;

		case '7':
			// code to be executed if
			// expression is equal to constant2;
			do {
				int a;
				long factorial = 1.0;
				cout << "Enter a positive integer: ";
				cin >> a;

				if (a < 0)
					cout << "Error! A negative number  do not have factorial ";
				else {
					int i = 1;
					while (i <= a) {
						factorial *= i;
						i++;
					}
					cout << "Factorial of " << a << " = " << factorial << endl;
				}

				cout << "if you want to use it again press 1 otherwise press 0 to close it " << endl;
				cin >> choice;
			} while (choice == 1);
			break;

		default:
			cout << "Wrong Input \n";

			}
			cout << "\nPress 1 if you want to ReRun this programe\n Press any other key to exit";
			cin >> choice;
		}
	} while (choice == 1);
	return 0;
