// #include <iostream>
// #include <string>
// using namespace std;

// int main(){
// cout << "hello/n";
// system("pause");
// return 0;
// }
//int main(){
//	int num1 = 0;
//	int num2 = 0;
//	int num3 = 0;
//	cout << "enter your first number";
//	cin >> num1;
//	cout << "enter your second number";
//	cin >> num2;
//	cout << "enter your third number";
//	cin >> num3;
//	float avg = 0.0;
//	avg = (num1 + num2 + num3) / 3;
//	int random;
//	random = rand();
//	int ans = 0.0;
//	ans = avg / random;
//	int(ans);
//	int chk = ans % 2;
//	cout << "the result is even in case of 0,odd otherwise ";
//	cout << chk;
//	return 0;
//}
//problem 2::                   (2nd)
//void main(){
//	string var1 = ("");
//	string var2 = ("");
//	string var3 = ("");
//	string var4 = ("");
//  string var5=(" ");

//	cout << "Enter the  first variable ";
//	cin >> var1;
//	cout << "Enter your second variable";
//	cin >> var2;
//	cout << "Enter your third variable ";
//	cin >> var3;
//cout<<"Enter your fourth variable";
//cin>>var4;
//	var5 = var1 + " " + var2 +" " + var3+(" ")+var4;
//	cout << var5 <<endl;
//	system("pause");
//}
// problem 3::                      (3rd)
//void main(){
//	cout << "the size of integer is: " << sizeof(int)<<endl;
//	cout << "the size of string is:  " << sizeof (string) << endl;
//	cout << "the size of character is:  " << sizeof(char)<<endl;
//	cout << "the size of float is:  " << sizeof(float) << endl;
//	cout << "the size of double is:  " << sizeof(double) << endl;
//	cout << "the size of long int is:   " << sizeof(long int)<<endl;
//	cout << "the size of short int is: " << sizeof(short int)<<endl;
//	system("pause");
//}
//problem 4::                     (4th)
//void main(){
//	std::string str = "123";
//	int num = 0;
//	num = stoi(str);
//	cout << "this is the number: " <<num<<" This is the string(\""<< num<<"\")";
//	system("pause");
//}
//problem 5::                         (5th)
//int main(){
//	int num1 = 0;
//	int num2 = 0;
//	int num3 = 0;
//	int num4 = 0;
//	int num5 = 0;
//	int num6 = 0;
//	float evencount = 0;
//	float oddcount = 0;
//	cout << "enter the  1st numbers : ";
//	cin >> num1;
//cout << "enter the  2nd number : ";
//	cin >> num2;
//cout << "enter the  3rd number : ";
//	cin >> num3;
//cout << "enter the  4th number : ";
//	cin >> num4;
//cout << "enter the  5th number : ";
//	cin >> num5;
//cout << "enter the  6th number : ";
//	cin >> num6;
//	if (num1 % 2==0){
//		evencount = evencount + 1;
//}
//	else
//	{
//		oddcount = oddcount + 1;
//
//	}
//	if (num2 % 2 == 0){
//		evencount = evencount + 1;
//	}
//	else
//	{
//		oddcount = oddcount + 1;
//
//	}if (num3 % 2 == 0){
//		evencount = evencount + 1;
//	}
//	else
//	{
//		oddcount = oddcount + 1;
//
//	}if (num4 % 2 == 0){
//		evencount = evencount + 1;
//	}
//	else
//	{
//		oddcount = oddcount + 1;
//
//	}if (num5 % 2 == 0){
//		evencount = evencount + 1;
//	}
//	else
//	{
//		oddcount = oddcount + 1;
//
//	}if (num6 % 2 == 0){
//		evencount = evencount + 1;
//	}
//	else
//	{
//		oddcount = oddcount + 1;
//	}
//	cout << " Evencount is : " << ((evencount / 6) * 100) << "%/n";
//	cout << "Oddcount is :" << ((oddcount / 6) * 100) << "%/n";
//	return 0;
//}
//problem 7::            (7th)
// int main(){
// 	double gross1;
// 	double gross2;
// 	double gross3;
// 	int salary;
// 	int chk;
// 	int gross;
// 	cout << "Enter your salary ";
// 	cin >>salary;
// 	gross1 = salary;
// 	gross2 = salary;
// 	gross3 = salary;
// 	for (int index1 = 0; index1 <5; index1++)
// 	{ gross1=((gross1*1.03)*0.985);
// 	}
// for (int index2 =0;index2<5;index2++)
// {
//     gross2=((gross2*1.14)*0.9);
// }
// gross3=(gross3*1.03)*0.985;
// gross3=(gross3*1.14)*0.9;
// gross3=(gross3*1.03)*0.985;
// gross3=(gross3*1.14)*0.9;
// gross3=(gross3*1.03)*0.985;
// gross=gross3;
// chk=gross%2;
// cout<<"1st Gross is : "<<gross1<<endl;
// cout<<"2nd Gross is : "<<gross2<<endl;
// cout<<"3rd Gross is : "<<gross3<<endl;
// cout<<"1=odd,o= even,total calculated gross is : "<<chk<<endl;
// return 0;
// }
